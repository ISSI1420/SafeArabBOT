from .menu import register as menu
from .deal import register as deal
from .user import register as user
from .admin import register as admin
from .rating import register as rating
from .blacklist import register as blacklist
from .referral import register as referral